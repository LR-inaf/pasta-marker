import os
import pastamarkers

__ROOT__    = os.path.dirname(pastamarkers.__file__)

dir_data = __ROOT__ + "/data/"

# "/mnt/c/Users/nicob/Desktop/pastamarkers/test/data/MPD/"