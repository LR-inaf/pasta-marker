# PASTA MARKER PROJECT
This is the amazing **pasta marker project** that will allow you to use a lot of the famous italian pasta types.